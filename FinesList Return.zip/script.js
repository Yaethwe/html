/* -------- Table Search Section -------- */
function TableSearch() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("Input");
    filter = input.value.toUpperCase();
    table = document.getElementById("Table");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
}

/* -------- Navigation Bar Section -------- */
function iconClick(){
    location.href="index.html";
}
function navbar() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
     }
}

/* -------- Not Available Section -------- */
function NA(){
	alert('Currently Not Available')
}

/* -------- Attendance Section -------- */
function Attendance(){
		let tables = document.querySelectorAll('td')
	
		tables.forEach(td => {
		let attend = td.textContent
		
		if( attend == "Attended"){
			td.style.color = "gold"
		}else if( attend == "Not Attended"){
			td.style.color = "red"
		}
		else{
			td.style.color = "blue"
		}
		
	})
	/*
	var attend = document.getElementById('td').value;
	var tableData = document.getElementsById('td');
	if( attend == "Attended"){
	tableData.style.backgroundColor = "green";
	}
	if( attend == "Not Attended"){
	tableData.style.backgroundColor = "red";
	}
	else{
	tableData.style.backgroundColor = "gray";
	}*/
}

Attendance()